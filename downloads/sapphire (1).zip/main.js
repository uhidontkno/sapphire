const scripts = ['app-950.chunk.js', 'menu.js'];
scripts.forEach(src => {
    document.head.appendChild(Object.assign(document.createElement('script'), {
        src: chrome.runtime.getURL(src)
    }));
});